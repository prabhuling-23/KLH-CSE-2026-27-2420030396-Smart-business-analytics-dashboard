/* =====================================================
   PRODUCT DATA
===================================================== */

let products = [

    {
        id: 1,
        name: "Wireless Charger",
        category: "Mobile Accessories",
        price: 899,
        emoji: "🔋",
        stock: 18
    },

    {
        id: 2,
        name: "Premium Phone Case",
        category: "Mobile Accessories",
        price: 499,
        emoji: "📱",
        stock: 32
    },

    {
        id: 3,
        name: "20000mAh Power Bank",
        category: "Mobile Accessories",
        price: 1199,
        emoji: "⚡",
        stock: 11
    },

    {
        id: 4,
        name: "Tempered Glass Screen Protector",
        category: "Mobile Accessories",
        price: 299,
        emoji: "🛡️",
        stock: 27
    },

    {
        id: 5,
        name: "Magnetic Phone Holder",
        category: "Mobile Accessories",
        price: 549,
        emoji: "🧲",
        stock: 8
    },


    {
        id: 6,
        name: "Salicylic Acid Face Wash",
        category: "Beauty",
        price: 349,
        emoji: "🧴",
        stock: 21
    },

    {
        id: 7,
        name: "Daily Sunscreen SPF 50",
        category: "Beauty",
        price: 599,
        emoji: "☀️",
        stock: 14
    },

    {
        id: 8,
        name: "Hair Curling Tool",
        category: "Beauty",
        price: 1299,
        emoji: "💇",
        stock: 6
    },

    {
        id: 9,
        name: "Ceramide Facial Serum",
        category: "Beauty",
        price: 749,
        emoji: "✨",
        stock: 17
    },

    {
        id: 10,
        name: "Vitamin C Face Serum",
        category: "Beauty",
        price: 699,
        emoji: "🍊",
        stock: 13
    },


    {
        id: 11,
        name: "Foldable Study Desk",
        category: "Home",
        price: 1899,
        emoji: "🪑",
        stock: 7
    },

    {
        id: 12,
        name: "Stackable Storage Bins",
        category: "Home",
        price: 799,
        emoji: "📦",
        stock: 19
    },

    {
        id: 13,
        name: "Mini Vegetable Chopper",
        category: "Home",
        price: 449,
        emoji: "🥕",
        stock: 23
    },

    {
        id: 14,
        name: "Decorative Doormat",
        category: "Home",
        price: 799,
        emoji: "🏡",
        stock: 9
    },

    {
        id: 15,
        name: "Under-Bed Storage Bag",
        category: "Home",
        price: 599,
        emoji: "🧺",
        stock: 15
    },


    {
        id: 16,
        name: "Performance Athleisure Set",
        category: "Fashion",
        price: 1499,
        emoji: "🏃",
        stock: 12
    },

    {
        id: 17,
        name: "Utility Cargo Pants",
        category: "Fashion",
        price: 1199,
        emoji: "👖",
        stock: 10
    },

    {
        id: 18,
        name: "Minimalist Jewelry Set",
        category: "Fashion",
        price: 599,
        emoji: "💎",
        stock: 16
    },

    {
        id: 19,
        name: "Genuine Leather Wallet",
        category: "Fashion",
        price: 899,
        emoji: "👛",
        stock: 8
    },

    {
        id: 20,
        name: "Oversized Casual T-Shirt",
        category: "Fashion",
        price: 699,
        emoji: "👕",
        stock: 25
    },


    {
        id: 21,
        name: "Premium Yoga Mat",
        category: "Health",
        price: 999,
        emoji: "🧘",
        stock: 18
    },

    {
        id: 22,
        name: "Resistance Band Set",
        category: "Health",
        price: 649,
        emoji: "🏋️",
        stock: 20
    },

    {
        id: 23,
        name: "Vegan Protein Powder",
        category: "Health",
        price: 1699,
        emoji: "🥤",
        stock: 9
    },

    {
        id: 24,
        name: "Insulated Water Bottle",
        category: "Health",
        price: 749,
        emoji: "🚰",
        stock: 22
    },

    {
        id: 25,
        name: "Fitness Foam Roller",
        category: "Health",
        price: 899,
        emoji: "🔵",
        stock: 7
    }

];


/* =====================================================
   APPLICATION STATE
===================================================== */

let activeCategory = "All";

let cart =
    JSON.parse(
        localStorage.getItem("smartCart")
        || "{}"
    );

let orders =
    JSON.parse(
        localStorage.getItem("smartOrders")
        || "[]"
    );

let sales =
    JSON.parse(
        localStorage.getItem("smartSales")
        || "{}"
    );


/* =====================================================
   SAVE DATA
===================================================== */

function saveData() {

    localStorage.setItem(
        "smartCart",
        JSON.stringify(cart)
    );

    localStorage.setItem(
        "smartOrders",
        JSON.stringify(orders)
    );

    localStorage.setItem(
        "smartSales",
        JSON.stringify(sales)
    );

}


/* =====================================================
   PAGE NAVIGATION
===================================================== */

function showPage(pageId) {

    document
        .querySelectorAll(".page")
        .forEach(
            page =>
            page.classList.remove("active")
        );

    document
        .getElementById(pageId)
        .classList.add("active");

    if(pageId === "shop")
        renderProducts();

    if(pageId === "analytics")
        refreshAnalytics();

    if(pageId === "admin")
        renderAdmin();

    window.scrollTo(0,0);

}


/* =====================================================
   CATEGORY
===================================================== */

function shopCategory(category) {

    showPage("shop");

    activeCategory = category;

    renderProducts();

}


function setCategory(category,button) {

    activeCategory = category;

    document
        .querySelectorAll("#shop .category")
        .forEach(
            b =>
            b.classList.remove("active")
        );

    button.classList.add("active");

    renderProducts();

}


/* =====================================================
   PRODUCT RENDER
===================================================== */

function renderProducts() {

    const search =
        document
            .getElementById("search")
            .value
            .toLowerCase();

    let list =
        products.filter(
            product =>

            (
                activeCategory === "All"
                ||
                product.category === activeCategory
            )

            &&

            product.name
                .toLowerCase()
                .includes(search)

        );


    document
        .getElementById("resultInfo")
        .textContent =
        list.length +
        " products available";


    document
        .getElementById("products")
        .innerHTML =

        list.length

        ?

        list
            .map(
                product => `

                <div class="product">

                    <div class="product-image">
                        ${product.emoji}
                    </div>

                    <div class="product-info">

                        <h3>
                            ${product.name}
                        </h3>

                        <small>
                            ${product.category}
                        </small>

                        <p>

                            <span class="price">
                                ₹${product.price}
                            </span>

                        </p>

                        <span
                            class="
                            stock
                            ${product.stock <= 8
                                ? "low-stock"
                                : ""}
                            "
                        >

                            ${
                                product.stock <= 8
                                ? "⚠ Low Stock"
                                : "✓ In Stock"
                            }

                            • ${product.stock}

                        </span>


                        <button
                            class="add-button"
                            onclick="addToCart(${product.id})"
                        >

                            Add to Cart

                        </button>

                    </div>

                </div>

                `
            )
            .join("")

        :

        `
        <div class="box">
            No products found.
        </div>
        `;


    updateCartCount();

}


/* =====================================================
   ADD TO CART
===================================================== */

function addToCart(id) {

    const product =
        products.find(
            p => p.id === id
        );


    if(
        (cart[id] || 0)
        >= product.stock
    ) {

        alert(
            "Maximum stock reached."
        );

        return;

    }


    cart[id] =
        (cart[id] || 0) + 1;


    saveData();

    updateCartCount();

    openCart();

}


/* =====================================================
   CHANGE QUANTITY
===================================================== */

function changeQuantity(id,change) {

    const product =
        products.find(
            p => p.id === id
        );


    let quantity =
        (cart[id] || 0)
        + change;


    if(quantity > product.stock) {

        alert(
            "Only "
            + product.stock
            + " units available."
        );

        return;

    }


    if(quantity <= 0) {

        delete cart[id];

    }
    else {

        cart[id] = quantity;

    }


    saveData();

    showCart();

}


/* =====================================================
   DELETE CART ITEM
===================================================== */

function deleteCartItem(id) {

    delete cart[id];

    saveData();

    showCart();

}


/* =====================================================
   CLEAR CART
===================================================== */

function clearCart() {

    if(
        !Object.keys(cart).length
    ) {

        return;

    }


    if(
        confirm(
            "Clear the entire cart?"
        )
    ) {

        cart = {};

        saveData();

        showCart();

    }

}


/* =====================================================
   CART COUNT
===================================================== */

function updateCartCount() {

    const count =
        Object
            .values(cart)
            .reduce(
                (sum,quantity) =>
                sum + Number(quantity),
                0
            );


    document
        .getElementById("cartCount")
        .textContent = count;

}


/* =====================================================
   SHOW CART
===================================================== */

function showCart() {

    const entries =
        Object.entries(cart);


    let subtotal = 0;


    document
        .getElementById("cartItems")
        .innerHTML =

        entries.length

        ?

        entries
            .map(
                ([id,quantity]) => {

                    const product =
                        products.find(
                            p => p.id == id
                        );


                    subtotal +=
                        product.price
                        * quantity;


                    return `

                    <div class="cart-item">

                        <div class="cart-emoji">
                            ${product.emoji}
                        </div>

                        <div style="flex:1">

                            <b>
                                ${product.name}
                            </b>

                            <div>
                                ₹${product.price}
                                × ${quantity}
                            </div>


                            <div class="quantity">

                                <button
                                    onclick="
                                    changeQuantity(
                                        ${product.id},
                                        -1
                                    )"
                                >
                                    −
                                </button>


                                ${quantity}


                                <button
                                    onclick="
                                    changeQuantity(
                                        ${product.id},
                                        1
                                    )"
                                >
                                    +
                                </button>


                                <button
                                    class="delete"
                                    onclick="
                                    deleteCartItem(
                                        ${product.id}
                                    )"
                                >
                                    🗑 Delete
                                </button>

                            </div>

                        </div>

                    </div>

                    `;

                }
            )
            .join("")

        :

        `
        <p>
            Your cart is empty.
        </p>
        `;


    const shipping =
        subtotal === 0
        ? 0
        : subtotal >= 2000
        ? 0
        : 79;


    const tax =
        subtotal * 0.08;


    const total =
        subtotal
        + shipping
        + tax;


    document
        .getElementById("cartSummary")
        .innerHTML =

        entries.length

        ?

        `

        <div class="cart-total">

            <div>
                Subtotal:
                ₹${subtotal.toLocaleString("en-IN")}
            </div>

            <div>
                Shipping:
                ${
                    shipping
                    ? "₹"+shipping
                    : "FREE"
                }
            </div>

            <div>
                Tax:
                ₹${tax.toFixed(2)}
            </div>

            <hr>

            Total:
            ₹${total.toFixed(2)}

        </div>


        <button
            class="checkout"
            onclick="checkout()"
        >
            Proceed to Checkout
        </button>


        <button
            class="clear-cart"
            onclick="clearCart()"
        >
            Clear Cart
        </button>

        `

        :

        "";

}


/* =====================================================
   OPEN CART
===================================================== */

function openCart() {

    document
        .getElementById("cartOverlay")
        .classList.add("show");

    showCart();

}


/* =====================================================
   CLOSE CART
===================================================== */

function closeCart() {

    document
        .getElementById("cartOverlay")
        .classList.remove("show");

}


/* =====================================================
   CHECKOUT
===================================================== */

function checkout() {

    if(
        !Object.keys(cart).length
    ) {

        alert(
            "Your cart is empty."
        );

        return;

    }


    const customer =
        prompt(
            "Enter customer name:"
        );


    if(!customer)
        return;


    let items = [];

    let total = 0;


    Object.entries(cart)
        .forEach(
            ([id,quantity]) => {

                const product =
                    products.find(
                        p => p.id == id
                    );


                total +=
                    product.price
                    * quantity;


                items.push({

                    name:
                        product.name,

                    quantity:
                        quantity,

                    price:
                        product.price

                });

            }
        );


    const order = {

        id:
            "ORD-"
            + Date.now(),

        customer:
            customer,

        date:
            new Date()
                .toLocaleString("en-IN"),

        items:
            items,

        total:
            total,

        status:
            "Processing"

    };


    orders.unshift(order);


    items.forEach(
        item => {

            const product =
                products.find(
                    p =>
                    p.name === item.name
                );


            sales[product.id] =
                (
                    sales[product.id]
                    || 0
                )
                + item.quantity;

        }
    );


    cart = {};


    saveData();

    updateCartCount();

    closeCart();

    alert(
        "Order placed successfully!\n"
        + order.id
    );


    refreshAnalytics();

    renderAdmin();

}


/* =====================================================
   ANALYTICS
===================================================== */

function refreshAnalytics() {

    const revenue =
        orders.reduce(
            (sum,order) =>
            sum + order.total,
            0
        );


    const predicted =
        revenue > 0

        ?

        revenue * 1.16

        :

        products
            .reduce(
                (sum,p) =>
                sum + p.price,
                0
            )
            * 0.18;


    const predictedOrders =
        Math.max(
            1,
            Math.round(
                orders.length * 1.15
                + 5
            )
        );


    const variance =
        revenue > 0

        ?

        (
            (predicted-revenue)
            / revenue
        ) * 100

        :

        100;


    document
        .getElementById("actualRevenue")
        .textContent =
        "₹"
        + revenue.toLocaleString(
            "en-IN"
        );


    document
        .getElementById("predictedRevenue")
        .textContent =
        "₹"
        + predicted.toFixed(0)
            .toLocaleString(
                "en-IN"
            );


    document
        .getElementById("predictedOrders")
        .textContent =
        predictedOrders;


    document
        .getElementById("actualMini")
        .textContent =
        "₹"
        + revenue.toFixed(0);


    document
        .getElementById("forecastMini")
        .textContent =
        "₹"
        + predicted.toFixed(0);


    document
        .getElementById("varianceMini")
        .textContent =
        variance.toFixed(1)
        + "%";


    document
        .getElementById("forecastBar")
        .style.width =
        Math.min(
            100,
            Math.max(
                10,
                revenue
                ? predicted/revenue*70
                : 70
            )
        )
        + "%";


    const risk =
        orders.length === 0
        ? 0.18
        : Math.min(
            0.92,
            0.18
            + 0.04
            * Math.max(
                0,
                5-orders.length
            )
        );


    document
        .getElementById("churnProbability")
        .textContent =
        Math.round(
            risk*100
        )
        + "%";


    document
        .getElementById("riskScore")
        .textContent =
        risk.toFixed(2);


    document
        .getElementById("riskLabel")
        .textContent =
        risk >= 0.70
        ? "HIGH RISK"
        : "LOW / MEDIUM RISK";


    document
        .getElementById("riskLabel")
        .className =
        risk >= 0.70
        ? "tag red"
        : "tag green";


    document
        .getElementById("drivers")
        .innerHTML = `

        <p>
            Support Contact Frequency
        </p>

        <div class="bar">
            <div
                class="bar-fill"
                style="width:95%"
            ></div>
        </div>

        <p>
            30/90-Day Spending Drift
        </p>

        <div class="bar">
            <div
                class="bar-fill"
                style="width:80%"
            ></div>
        </div>

        <p>
            Cart Abandonment Ratio
        </p>

        <div class="bar">
            <div
                class="bar-fill"
                style="width:65%"
            ></div>
        </div>

        `;


    document
        .getElementById("anomaly")
        .textContent =

        variance > 15

        ?

        "🚨 Forecast variance exceeds 15%"

        :

        "✓ Forecast within monitoring range";


    renderForecast();

}


/* =====================================================
   PRODUCT FORECAST
===================================================== */

function renderForecast() {

    document
        .getElementById("forecastTable")
        .innerHTML =

        products
            .map(
                product => {

                    const sold =
                        sales[product.id]
                        || 0;


                    const predicted =
                        Math.max(
                            1,
                            Math.round(
                                sold * 1.25
                                + 1
                            )
                        );


                    const expected =
                        predicted
                        * product.price;


                    const outcome =
                        product.stock
                        <= predicted

                        ?

                        "Replenish Stock"

                        :

                        predicted >= 5

                        ?

                        "Strong Demand"

                        :

                        "Stable Demand";


                    return `

                    <tr>

                        <td>
                            ${product.emoji}
                            ${product.name}
                        </td>

                        <td>
                            ${product.stock}
                        </td>

                        <td>
                            ${sold}
                        </td>

                        <td>
                            ${predicted}
                        </td>

                        <td>
                            ₹${expected.toLocaleString(
                                "en-IN"
                            )}
                        </td>

                        <td>

                            <span
                                class="
                                tag
                                ${
                                    outcome ===
                                    "Strong Demand"
                                    ? "green"
                                    : "yellow"
                                }
                                "
                            >

                                ${outcome}

                            </span>

                        </td>

                    </tr>

                    `;

                }
            )
            .join("");

}


/* =====================================================
   WHAT-IF SCENARIO
===================================================== */

function scenario() {

    const revenue =
        orders.reduce(
            (sum,o) =>
            sum + o.total,
            0
        );


    const base =
        revenue > 0
        ? revenue * 1.16
        : 100000;


    const price =
        Number(
            document
                .getElementById(
                    "priceSlider"
                )
                .value
        );


    const marketing =
        Number(
            document
                .getElementById(
                    "marketingSlider"
                )
                .value
        );


    const inventory =
        Number(
            document
                .getElementById(
                    "inventorySlider"
                )
                .value
        );


    const scenarioRevenue =
        base
        *
        (1 + marketing * 0.012)
        *
        (1 - price * 0.006)
        *
        (inventory / 100);


    const growth =
        (
            (
                scenarioRevenue-base
            )
            /
            base
        )
        * 100;


    document
        .getElementById(
            "priceValue"
        )
        .textContent =
        price + "%";


    document
        .getElementById(
            "marketingValue"
        )
        .textContent =
        marketing + "%";


    document
        .getElementById(
            "inventoryValue"
        )
        .textContent =
        inventory + "%";


    document
        .getElementById(
            "scenarioRevenue"
        )
        .textContent =
        "₹"
        + scenarioRevenue
            .toFixed(0);


    document
        .getElementById(
            "scenarioGrowth"
        )
        .textContent =
        (
            growth >= 0
            ? "+"
            : ""
        )
        +
        growth.toFixed(1)
        +
        "%";


    document
        .getElementById(
            "scenarioOutcome"
        )
        .textContent =

        growth > 12
        ? "High Growth"

        : growth > 3
        ? "Positive"

        : "Stable";

}


/* =====================================================
   ADMIN
===================================================== */

function renderAdmin() {

    const revenue =
        orders.reduce(
            (sum,o) =>
            sum + o.total,
            0
        );


    const lowStock =
        products.filter(
            p => p.stock <= 8
        ).length;


    document
        .getElementById(
            "adminProducts"
        )
        .textContent =
        products.length;


    document
        .getElementById(
            "adminLowStock"
        )
        .textContent =
        lowStock;


    document
        .getElementById(
            "adminOrders"
        )
        .textContent =
        orders.length;


    document
        .getElementById(
            "adminRevenue"
        )
        .textContent =
        "₹"
        + revenue.toLocaleString(
            "en-IN"
        );


    document
        .getElementById(
            "inventoryTable"
        )
        .innerHTML =

        products
            .map(
                product => `

                <tr>

                    <td>
                        ${product.emoji}
                        ${product.name}
                    </td>

                    <td>
                        ${product.category}
                    </td>

                    <td>
                        ₹${product.price}
                    </td>

                    <td>
                        ${product.stock}
                    </td>

                    <td>

                        <button
                            class="primary"
                            onclick="
                            restock(
                                ${product.id}
                            )"
                        >
                            +10 Stock
                        </button>

                    </td>

                </tr>

                `
            )
            .join("");

}


/* =====================================================
   RESTOCK
===================================================== */

function restock(id) {

    const product =
        products.find(
            p => p.id === id
        );


    product.stock += 10;


    renderAdmin();

    renderProducts();

    renderForecast();

}


/* =====================================================
   INITIALIZE
===================================================== */

renderProducts();

renderAdmin();

refreshAnalytics();

scenario();

updateCartCount();
