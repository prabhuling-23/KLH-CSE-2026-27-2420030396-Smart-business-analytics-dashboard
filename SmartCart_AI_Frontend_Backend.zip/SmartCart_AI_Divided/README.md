# SmartCart AI — Frontend / Backend

frontend/
- index.html: UI structure
- style.css: styling
- app.js: browser-side interaction and current localStorage demo logic

backend/
- main.py: FastAPI REST API
- requirements.txt: Python dependencies

## Run backend
cd backend
python -m venv venv
venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn main:app --reload

API: http://127.0.0.1:8000
Docs: http://127.0.0.1:8000/docs

## Run frontend
Open frontend/index.html directly in Chrome for the current UI demo.

For API development, serve frontend:
cd frontend
python -m http.server 5500
Then open http://127.0.0.1:5500

Note: this split separates the existing front-end code and provides a runnable FastAPI backend. The current frontend still uses its existing localStorage logic; the next step is to replace those local calls with API calls and then add PostgreSQL/ML services.
