from datetime import datetime
from typing import Any
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="SmartCart AI Backend", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

products = [
    {"id": 1, "name": "Wireless Charger", "category": "Mobile Accessories", "price": 899, "emoji": "🔋", "stock": 18},
    {"id": 2, "name": "Premium Phone Case", "category": "Mobile Accessories", "price": 499, "emoji": "📱", "stock": 32},
    {"id": 3, "name": "20000mAh Power Bank", "category": "Mobile Accessories", "price": 1199, "emoji": "⚡", "stock": 11},
    {"id": 4, "name": "Tempered Glass Screen Protector", "category": "Mobile Accessories", "price": 299, "emoji": "🛡️", "stock": 27},
    {"id": 5, "name": "Magnetic Phone Holder", "category": "Mobile Accessories", "price": 549, "emoji": "🧲", "stock": 8},
    {"id": 6, "name": "Salicylic Acid Face Wash", "category": "Beauty", "price": 349, "emoji": "🧴", "stock": 21},
    {"id": 7, "name": "Daily Sunscreen SPF 50", "category": "Beauty", "price": 599, "emoji": "☀️", "stock": 14},
    {"id": 8, "name": "Hair Curling Tool", "category": "Beauty", "price": 1299, "emoji": "💇", "stock": 6},
    {"id": 9, "name": "Ceramide Facial Serum", "category": "Beauty", "price": 749, "emoji": "✨", "stock": 17},
    {"id": 10, "name": "Vitamin C Face Serum", "category": "Beauty", "price": 699, "emoji": "🍊", "stock": 13},
    {"id": 11, "name": "Foldable Study Desk", "category": "Home", "price": 1899, "emoji": "🪑", "stock": 7},
    {"id": 12, "name": "Stackable Storage Bins", "category": "Home", "price": 799, "emoji": "📦", "stock": 19},
    {"id": 13, "name": "Mini Vegetable Chopper", "category": "Home", "price": 449, "emoji": "🥕", "stock": 23},
    {"id": 14, "name": "Decorative Doormat", "category": "Home", "price": 799, "emoji": "🏡", "stock": 9},
    {"id": 15, "name": "Under-Bed Storage Bag", "category": "Home", "price": 599, "emoji": "🧺", "stock": 15},
    {"id": 16, "name": "Performance Athleisure Set", "category": "Fashion", "price": 1499, "emoji": "🏃", "stock": 12},
    {"id": 17, "name": "Utility Cargo Pants", "category": "Fashion", "price": 1199, "emoji": "👖", "stock": 10},
    {"id": 18, "name": "Minimalist Jewelry Set", "category": "Fashion", "price": 599, "emoji": "💎", "stock": 16},
    {"id": 19, "name": "Genuine Leather Wallet", "category": "Fashion", "price": 899, "emoji": "👛", "stock": 8},
    {"id": 20, "name": "Oversized Casual T-Shirt", "category": "Fashion", "price": 699, "emoji": "👕", "stock": 25},
    {"id": 21, "name": "Premium Yoga Mat", "category": "Health", "price": 999, "emoji": "🧘", "stock": 18},
    {"id": 22, "name": "Resistance Band Set", "category": "Health", "price": 649, "emoji": "🏋️", "stock": 20},
    {"id": 23, "name": "Vegan Protein Powder", "category": "Health", "price": 1699, "emoji": "🥤", "stock": 9},
    {"id": 24, "name": "Insulated Water Bottle", "category": "Health", "price": 749, "emoji": "🚰", "stock": 22},
    {"id": 25, "name": "Fitness Foam Roller", "category": "Health", "price": 899, "emoji": "🔵", "stock": 7},
]

orders: list[dict[str, Any]] = []

class OrderItem(BaseModel):
    name: str
    quantity: int = Field(ge=1)
    price: float = Field(ge=0)

class Order(BaseModel):
    id: str
    customer: str
    date: str
    items: list[OrderItem]
    total: float = Field(ge=0)
    status: str = "Processing"

@app.get("/")
def root():
    return {"message": "SmartCart AI Backend is running", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "UP"}

@app.get("/api/products")
def get_products():
    return products

@app.get("/api/products/{product_id}")
def get_product(product_id: int):
    for product in products:
        if product["id"] == product_id:
            return product
    raise HTTPException(status_code=404, detail="Product not found")

@app.post("/api/orders")
def create_order(order: Order):
    for item in order.items:
        product = next((p for p in products if p["name"] == item.name), None)
        if product is None:
            raise HTTPException(status_code=400, detail=f"Unknown product: {item.name}")
        if item.quantity > product["stock"]:
            raise HTTPException(status_code=400, detail=f"Insufficient stock for {item.name}")
    for item in order.items:
        product = next(p for p in products if p["name"] == item.name)
        product["stock"] -= item.quantity
    saved = order.model_dump()
    saved["created_at"] = datetime.now().isoformat()
    orders.insert(0, saved)
    return {"message": "Order created", "order": saved}

@app.get("/api/orders")
def get_orders():
    return orders

@app.get("/api/analytics")
def analytics():
    revenue = sum(float(o["total"]) for o in orders)
    predicted = revenue * 1.16 if revenue > 0 else sum(p["price"] for p in products) * 0.18
    return {
        "actual_revenue": round(revenue, 2),
        "forecast_30_day": round(predicted, 2),
        "predicted_orders": max(5, round(predicted / 750)),
        "churn_probability": 0.18 if not orders else min(0.95, 0.18 + 0.02 * max(0, 10-len(orders))),
        "model_confidence": 0.88,
        "orders": len(orders),
        "xai_drivers": [
            {"name": "Customer Support Contact Frequency", "importance": 0.38},
            {"name": "30/90-Day Spending Drift", "importance": 0.32},
            {"name": "Cart Abandonment Ratio", "importance": 0.26},
        ],
    }
